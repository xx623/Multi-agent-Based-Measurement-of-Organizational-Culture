# Pilot summary: control arm --no-isolation

Descriptive figures from single runs at fixed decoding; no validity claim. Technical Appendix H, Table H1, quotes this table.

| Quantity | Value |
|---|---|
| Passages processed | 1: 1 valid, 0 explicit abstentions, 0 invalid after the permitted retry |
| By source (valid / abstained / invalid) | constructed 1 / 0 / 0; public 0 / 0 / 0; licensed 0 / 0 / 0 |
| Reader's conduct items, initial and revised | 1 and 1 (1 passages) |
| Declarations in the ledger | 1 |
| Skeptic flags | 1 in 1 of 1 passages: omitted qualifier 1 |
| Reader responses to flags | defended 1 |
| Unresolved source objections in the view | 0; completeness uncertain in 0 of 1 passages |
| Judge claims, round 1 | 1: supported 1 |
| Critic objections, round 1 | 1: alternative reading 1; 0 claims accepted without objection |
| Judge responses to objections, round 2 | claim narrowed 1 |
| Judge claims, round 2 | 1: partially supported 1; no claim left in 0 passages |
| Critic objections, round 2 | 1; 0 round-1 objections resolved |
| Adjudication of round-2 claims | narrowed 1 (0 of the withheld already marked insufficient evidence by the Judge) |
| Claims in the final measurement records | 1 in 1 passages: collaboration and people-focused, weak, required routine (1) |
| Limitations on retained claims | resolvable 1 |
| Passages escalated to human review | 1 of 1 |
| Boundary checks on interpretation calls; violations | 3; 0 |
| Calls needing the one permitted retry | 1 of 8: Reader (initial) 1 |
| Invalid passages | none |
| Tokens per completed passage, mean | 22,248 input and 1,960 output with retries (20,891 and 1,748 without); local inference, no marginal price |
| Model time per completed passage | mean 32.8 s, median 32.8 s, retries included |

| Passage | Source | Status | Flags | Objections | Round-2 claims | Actions | Retained | Escalate | Retried calls | Tokens in/out | Model time s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| DEMO-C:001 | constructed | valid | 1 | 1 | 1 | {'narrow': 1} | 1 | True | 1 | 22248/1960 | 32.8 |
