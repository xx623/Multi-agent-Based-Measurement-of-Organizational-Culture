# Pilot summary: pilot full design, five roles

Descriptive figures from single runs at fixed decoding; no validity claim. Technical Appendix H, Table H1, quotes this table.

| Quantity | Value |
|---|---|
| Passages processed | 17: 12 valid, 4 explicit abstentions, 1 invalid after the permitted retry |
| By source (valid / abstained / invalid) | constructed 1 / 0 / 0; public 3 / 1 / 0; licensed 8 / 3 / 1 |
| Reader's conduct items, initial and revised | 43 and 62 (16 passages) |
| Declarations in the ledger | 11 |
| Skeptic flags | 52 in 16 of 16 passages: omitted qualifier 31, missing item 20, ignored counterevidence 1 |
| Reader responses to flags | item added 21, defended 19, amended 12 |
| Unresolved source objections in the view | 36; completeness uncertain in 6 of 16 passages |
| Judge claims, round 1 | 28: supported 5, partially supported 2, insufficient evidence 21 |
| Critic objections, round 1 | 23: episode generalized to a norm 15, alternative reading 7, culture inferred from a formal rule 1; 5 claims accepted without objection |
| Judge responses to objections, round 2 | objection accepted 18, claim narrowed 3, claim defended 2 |
| Judge claims, round 2 | 12: supported 4, partially supported 2, insufficient evidence 6; no claim left in 9 passages |
| Critic objections, round 2 | 22; 1 round-1 objection resolved |
| Adjudication of round-2 claims | accepted 1, narrowed 2, withheld 9 (6 of the withheld already marked insufficient evidence by the Judge) |
| Claims in the final measurement records | 3 in 3 passages: performance-oriented, strong, required routine (2); collaboration and people-focused, weak, required routine (1) |
| Limitations on retained claims | source-inherent 2, resolvable 1 |
| Passages escalated to human review | 6 of 16 |
| Boundary checks on interpretation calls; violations | 80; 0 |
| Calls needing the one permitted retry | 43 of 129: adjudicator 13, critic round 2 9, Judge round 1 8, Reader (revision) 7, Reader (initial) 4, Judge round 2 2 |
| Invalid passages | 1: licensed passage C096470cf42:w003, Reader (initial): excerpt over the 25-word limit after the retry |
| Tokens per completed passage, mean | 36,841 input and 4,304 output with retries (27,042 and 3,028 without); local inference, no marginal price |
| Model time per completed passage | mean 63.0 s, median 61.1 s, retries included |

| Passage | Source | Status | Flags | Objections | Round-2 claims | Actions | Retained | Escalate | Retried calls | Tokens in/out | Model time s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| C096470cf42:w002 | licensed | abstained | 2 | 1 | 0 | {} | 0 | True | 5 | 53282/7969 | 125.2 |
| C096470cf42:w003 | licensed | invalid | None | None | None | None | None | None | 1 | 4223/1475 | 22.0 |
| C096470cf42:w004 | licensed | valid | 1 | 1 | 0 | {} | 0 | False | 3 | 33103/2984 | 44.6 |
| C096470cf42:w039 | licensed | valid | 2 | 1 | 0 | {} | 0 | False | 2 | 34980/3313 | 49.2 |
| C1d9dee3ea5:w002 | licensed | valid | 3 | 1 | 1 | {'withhold': 1} | 0 | True | 3 | 35117/3684 | 53.1 |
| C1d9dee3ea5:w003 | licensed | valid | 6 | 1 | 1 | {'withhold': 1} | 0 | False | 3 | 44776/6359 | 89.9 |
| C1d9dee3ea5:w004 | licensed | valid | 4 | 1 | 0 | {} | 0 | False | 3 | 39460/4690 | 68.3 |
| C1d9dee3ea5:w026 | licensed | valid | 1 | 1 | 2 | {'withhold': 2} | 0 | False | 2 | 31556/2813 | 42.2 |
| C5290b5f4b2:w002 | licensed | valid | 4 | 1 | 0 | {} | 0 | False | 2 | 35026/3698 | 54.1 |
| C5290b5f4b2:w003 | licensed | abstained | 4 | 3 | 0 | {} | 0 | True | 3 | 41013/4592 | 66.0 |
| C5290b5f4b2:w004 | licensed | valid | 4 | 3 | 4 | {'withhold': 3, 'accept': 1} | 1 | False | 1 | 32977/5066 | 73.0 |
| C5290b5f4b2:w022 | licensed | abstained | 4 | 3 | 0 | {} | 0 | True | 3 | 40105/4239 | 61.2 |
| DEMO-C:001 | constructed | valid | 1 | 1 | 1 | {'narrow': 1} | 1 | False | 1 | 22331/2034 | 31.4 |
| PUBLIC-TRAK-2026Q2:w001 | public | valid | 4 | 2 | 2 | {'withhold': 1, 'narrow': 1} | 1 | True | 3 | 40706/5717 | 80.7 |
| PUBLIC-TRAK-2026Q2:w002 | public | valid | 3 | 1 | 0 | {} | 0 | False | 3 | 32795/2460 | 36.8 |
| PUBLIC-TRAK-2026Q2:w003 | public | valid | 3 | 1 | 1 | {'withhold': 1} | 0 | False | 3 | 36484/4265 | 61.0 |
| PUBLIC-TRAK-2026Q2:w004 | public | abstained | 6 | 1 | 0 | {} | 0 | True | 2 | 35738/4980 | 70.7 |
