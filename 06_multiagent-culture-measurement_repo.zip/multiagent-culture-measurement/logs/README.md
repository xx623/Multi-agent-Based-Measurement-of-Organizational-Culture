# Pilot logs

Each batch folder is the release copy of a run of `run_workflow.py` on the pinned local
model (`config/model_pins.json`). Per passage: `config.json` (arm, template hashes,
decoding), `input.json`, `calls/NN_<ID>.prompt.txt` (rendered prompt), `.inputs.json`
(the exact objects passed, which is what a reviewer should check for the information
boundary), `.attemptK.raw.txt` (every raw reply), `.output.json` (validated output),
`.meta.json` (tokens, latency, validation attempts), `record_initial.json`,
`record_revised.json`, `record_interp.json` (the interpretation view), `final/measurement.json`,
`final/process.json`, `summary.json` and `log.jsonl`. Per batch: `batch_summary.json`,
`cost_log.csv`, `pilot_summary.json` / `.md` (passages processed, flag and challenge
rates, narrowing and withholding, escalations, tokens, latency and cost per passage) and
`profile.csv`.

Passages whose `license` is `restricted` come from licensed LSEG StreetEvents transcripts.
For those, the release copy replaces the masked source window in the Reader and skeptic
calls with a placeholder (sentence count and hash) and blanks any run of six or more
passage words outside the verified excerpts (`pipeline/redact.py`; `REDACTION.json` per
passage records what was touched). Interpretation-stage inputs are released in full.
Public-record and constructed passages are released unredacted.

| Batch | Content |
|---|---|
| `pilot_2026-10-31_qwen2.5-14b/` | Full design (arm A-D-F), five roles: the constructed passage, four public passages, twelve restricted windows from three licensed transcripts |
| `arms_2026-10-31_qwen2.5-14b/` | Control arms B, C and E on the constructed passage (shared calls reused from cache) |
| `experts_2026-10-31_qwen2.5-14b/` | The six-expertise-agent extension on the constructed passage (fourteen calls) |

Figures are descriptive. No validity claim follows from them.
