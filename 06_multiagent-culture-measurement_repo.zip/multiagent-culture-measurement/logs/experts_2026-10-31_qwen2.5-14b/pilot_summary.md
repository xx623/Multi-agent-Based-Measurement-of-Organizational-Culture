# Pilot summary: expertise extension

Descriptive figures from single runs at fixed decoding; no validity claim. Technical Appendix H, Table H1, quotes this table.

| Quantity | Value |
|---|---|
| Passages processed | 1: 0 valid, 1 explicit abstentions, 0 invalid after the permitted retry |
| By source (valid / abstained / invalid) | constructed 0 / 1 / 0; public 0 / 0 / 0; licensed 0 / 0 / 0 |
| Reader's conduct items, initial and revised | 1 and 1 (1 passages) |
| Declarations in the ledger | 1 |
| Skeptic flags | 1 in 1 of 1 passages: omitted qualifier 1 |
| Reader responses to flags | defended 1 |
| Unresolved source objections in the view | 0; completeness uncertain in 0 of 1 passages |
| Judge claims, round 1 | 5: supported 1, partially supported 4 |
| Critic objections, round 1 | 1: alternative reading 1; 4 claims accepted without objection |
| Judge responses to objections, round 2 | claim narrowed 1 |
| Judge claims, round 2 | 5: supported 1, partially supported 4; no claim left in 0 passages |
| Critic objections, round 2 | 1; 0 round-1 objections resolved |
| Adjudication of round-2 claims | withheld 5 (0 of the withheld already marked insufficient evidence by the Judge) |
| Claims in the final measurement records | 0 in 0 passages:  |
| Limitations on retained claims | none |
| Passages escalated to human review | 1 of 1 |
| Boundary checks on interpretation calls; violations | 11; 0 |
| Calls needing the one permitted retry | 3 of 14: adjudicator 1, Reader (initial) 1, T2 1 |
| Invalid passages | none |
| Tokens per completed passage, mean | 43,615 input and 5,085 output with retries (35,779 and 4,154 without); local inference, no marginal price |
| Model time per completed passage | mean 78.6 s, median 78.6 s, retries included |

| Passage | Source | Status | Flags | Objections | Round-2 claims | Actions | Retained | Escalate | Retried calls | Tokens in/out | Model time s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| DEMO-C:001 | constructed | abstained | 1 | 1 | 5 | {'withhold': 5} | 0 | True | 3 | 43615/5085 | 78.6 |
